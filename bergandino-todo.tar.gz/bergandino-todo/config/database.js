module.exports = {
	// typically would never pass username/password directly in code but doing here for simplicity
    remoteUrl : 'mongodb://jbergandino:john1234@ds155278.mlab.com:55278/jbergandino',
};
